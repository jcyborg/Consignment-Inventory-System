﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Configuration;
using System.Data.SqlClient;
using ConsignmentCompanyProject.com.app.dataobjects;

namespace ConsignmentCompanyProject.windows.forms
{
    public partial class DeleteUser : Form
    {
        public DeleteUser()
        {
            InitializeComponent();
        }

        private void selectGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void byUserIDRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void deleteUserButton_Click(object sender, EventArgs e)
        {
          /*  if (userTextBox.Text !=null)
            {
                if (byUserIDRadioButton.Checked) 
                {
                    SqlCommand cmd = new SqlCommand("delete USER_TABLE where User ID = @USER_ID", con);
                    con.Open();

                    ProcessCmdKey.Parameters.AddWithValue("@USER_ID", userTextBox.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    displayGridView.Show("Record Deleted Successfully!");
                    DisplayData();
                    ClearData();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("delete USER_TABLE where User ID = @USER_ID", con);
                    con.Open();

                    ProcessCmdKey.Parameters.AddWithValue("@NAME", userTextBox.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    displayGridView.Text("Record Deleted Successfully!");
                    DisplayData();
                    ClearData();
                }
                

            }
            else
            {
                displayGridView.Text("Please Select Record to Delete6gv ");
            } */
        }

        private void search_Button_Click(object sender, EventArgs e)
        {
            try
            {

            

            if (userTextBox.Text != null)
            {
                if (byUserIDRadioButton.Checked)
                {
                    List<string> USER_NAME = new List<string>();

                    SqlConnection con = new SqlConnection("ConsignmentCompanyProject.Properties.Settings.ConsignmentStoreDBConnection");
                    SqlDataReader reader;
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT NAME, CONTACT, ADDRESS, EMAIL_ID FROM ConsignmentStoreDB.USER_TABLE WHERE NAME LIKE @NAME";
                    cmd.Parameters.AddWithValue("@USER_TABLE", displayGridView.Text);

                    con.Open();
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string username = reader["NAME"].ToString();
                        username += ", " + reader["ADDRESS"].ToString();
                        USER_NAME.Add(username);
                    }
                    reader.Close();

                }
                else
                {
                    List<string> USER_ID = new List<string>();

                    SqlConnection con = new SqlConnection("ConsignmentCompanyProject.Properties.Settings.ConsignmentStoreDBConnection");
                    SqlDataReader reader;
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT NAME, CONTACT, ADDRESS, EMAIL_ID FROM ConsignmentStoreDB.USER_TABLE WHERE USER_ID LIKE @USER_ID";
                    cmd.Parameters.AddWithValue("@USER_TABLE", displayGridView.Text);

                    con.Open();
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string userID = reader["USER_ID"].ToString();
                        userID += ", " + reader["ADDRESS"].ToString();
                        USER_ID.Add(userID);
                    }
                    reader.Close();
                }
               

            }
            }
            catch (Exception ex)
            {
             
            }
        }
    }
}
