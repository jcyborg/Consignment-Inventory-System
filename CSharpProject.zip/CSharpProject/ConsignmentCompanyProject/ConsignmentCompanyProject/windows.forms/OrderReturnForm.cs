﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsignmentCompanyProject.windows.forms
{
    public partial class OrderReturnForm : Form
    {
        public OrderReturnForm()
        {
            InitializeComponent();
        }

        private void listBoxReturnOrderItem_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
