﻿namespace ConsignmentCompanyProject.windows.forms
{
    partial class DeleteUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.deactivateUserLabel = new System.Windows.Forms.Label();
            this.byNameRadioButton = new System.Windows.Forms.RadioButton();
            this.byUserIDRadioButton = new System.Windows.Forms.RadioButton();
            this.selectGroupBox = new System.Windows.Forms.GroupBox();
            this.idLabel = new System.Windows.Forms.Label();
            this.displayGridView = new System.Windows.Forms.DataGridView();
            this.exitButton = new System.Windows.Forms.Button();
            this.deleteUserButton = new System.Windows.Forms.Button();
            this.userTextBox = new System.Windows.Forms.TextBox();
            this.search_Button = new System.Windows.Forms.Button();
            this.selectGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.displayGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // deactivateUserLabel
            // 
            this.deactivateUserLabel.AutoSize = true;
            this.deactivateUserLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deactivateUserLabel.Location = new System.Drawing.Point(256, 19);
            this.deactivateUserLabel.Name = "deactivateUserLabel";
            this.deactivateUserLabel.Size = new System.Drawing.Size(185, 24);
            this.deactivateUserLabel.TabIndex = 0;
            this.deactivateUserLabel.Text = "DEACTIVATE USER";
            // 
            // byNameRadioButton
            // 
            this.byNameRadioButton.AutoSize = true;
            this.byNameRadioButton.Location = new System.Drawing.Point(332, 35);
            this.byNameRadioButton.Name = "byNameRadioButton";
            this.byNameRadioButton.Size = new System.Drawing.Size(68, 17);
            this.byNameRadioButton.TabIndex = 1;
            this.byNameRadioButton.TabStop = true;
            this.byNameRadioButton.Text = "By Name";
            this.byNameRadioButton.UseVisualStyleBackColor = true;
            // 
            // byUserIDRadioButton
            // 
            this.byUserIDRadioButton.AutoSize = true;
            this.byUserIDRadioButton.Location = new System.Drawing.Point(189, 35);
            this.byUserIDRadioButton.Name = "byUserIDRadioButton";
            this.byUserIDRadioButton.Size = new System.Drawing.Size(76, 17);
            this.byUserIDRadioButton.TabIndex = 2;
            this.byUserIDRadioButton.TabStop = true;
            this.byUserIDRadioButton.Text = "By User ID";
            this.byUserIDRadioButton.UseVisualStyleBackColor = true;
            this.byUserIDRadioButton.CheckedChanged += new System.EventHandler(this.byUserIDRadioButton_CheckedChanged);
            // 
            // selectGroupBox
            // 
            this.selectGroupBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.selectGroupBox.Controls.Add(this.search_Button);
            this.selectGroupBox.Controls.Add(this.idLabel);
            this.selectGroupBox.Controls.Add(this.displayGridView);
            this.selectGroupBox.Controls.Add(this.exitButton);
            this.selectGroupBox.Controls.Add(this.deleteUserButton);
            this.selectGroupBox.Controls.Add(this.userTextBox);
            this.selectGroupBox.Controls.Add(this.byUserIDRadioButton);
            this.selectGroupBox.Controls.Add(this.byNameRadioButton);
            this.selectGroupBox.Location = new System.Drawing.Point(71, 71);
            this.selectGroupBox.Name = "selectGroupBox";
            this.selectGroupBox.Size = new System.Drawing.Size(627, 318);
            this.selectGroupBox.TabIndex = 3;
            this.selectGroupBox.TabStop = false;
            this.selectGroupBox.Text = "Select One";
            this.selectGroupBox.Enter += new System.EventHandler(this.selectGroupBox_Enter);
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.Location = new System.Drawing.Point(186, 76);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(71, 13);
            this.idLabel.TabIndex = 8;
            this.idLabel.Text = "Enter User ID";
            // 
            // displayGridView
            // 
            this.displayGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.displayGridView.Location = new System.Drawing.Point(162, 109);
            this.displayGridView.Name = "displayGridView";
            this.displayGridView.Size = new System.Drawing.Size(344, 150);
            this.displayGridView.TabIndex = 7;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(315, 279);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // deleteUserButton
            // 
            this.deleteUserButton.Location = new System.Drawing.Point(162, 279);
            this.deleteUserButton.Name = "deleteUserButton";
            this.deleteUserButton.Size = new System.Drawing.Size(75, 23);
            this.deleteUserButton.TabIndex = 5;
            this.deleteUserButton.Text = "Delete";
            this.deleteUserButton.UseVisualStyleBackColor = true;
            this.deleteUserButton.Click += new System.EventHandler(this.deleteUserButton_Click);
            // 
            // userTextBox
            // 
            this.userTextBox.Location = new System.Drawing.Point(300, 73);
            this.userTextBox.Name = "userTextBox";
            this.userTextBox.Size = new System.Drawing.Size(100, 20);
            this.userTextBox.TabIndex = 3;
            // 
            // search_Button
            // 
            this.search_Button.Location = new System.Drawing.Point(431, 71);
            this.search_Button.Name = "search_Button";
            this.search_Button.Size = new System.Drawing.Size(75, 23);
            this.search_Button.TabIndex = 9;
            this.search_Button.Text = "Search";
            this.search_Button.UseVisualStyleBackColor = true;
            this.search_Button.Click += new System.EventHandler(this.search_Button_Click);
            // 
            // DeleteUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 414);
            this.Controls.Add(this.selectGroupBox);
            this.Controls.Add(this.deactivateUserLabel);
            this.Name = "DeleteUser";
            this.Text = "DeleteUser";
            this.selectGroupBox.ResumeLayout(false);
            this.selectGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.displayGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label deactivateUserLabel;
        private System.Windows.Forms.RadioButton byNameRadioButton;
        private System.Windows.Forms.RadioButton byUserIDRadioButton;
        private System.Windows.Forms.GroupBox selectGroupBox;
        private System.Windows.Forms.TextBox userTextBox;
        private System.Windows.Forms.DataGridView displayGridView;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button deleteUserButton;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.Button search_Button;
    }
}